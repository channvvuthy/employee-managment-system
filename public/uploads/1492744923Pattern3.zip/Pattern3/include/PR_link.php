<?php
$index[0] = '<h3>タイトルタイトルタイトル</h3>サンプル<a href="http://hogehoge.co.jp/">PR_Link1‐サンプル</a>リンク';
$index[1] = '<h3>タイトルタイトルタイトル</h3>サンプルサンプルサンプルサンプル<a href="http://hogehoge.co.jp/">PR_Link2‐サンプルサンプル</a>サンプルサンプルサンプルサンプルサンプルサンプルリンク';
$index[2] = '<h3>タイトルタイトルタイトル</h3>サンプルサンプル<a href="http://hogehoge.co.jp/">PR_Link3‐サンプルサンプル</a>サンプルリンク';
$index[3] = '<h3>タイトルタイトルタイトル</h3>サンプル<a href="http://hogehoge.co.jp/">PR_Link4‐サンプルサンプルサンプルサンプル</a>サンプルサンプルサンプルリンク';
$index[4] = '<h3>タイトルタイトルタイトル</h3><a href="http://hogehoge.co.jp/">PR_Link5‐サンプルサンプル</a>サンプルリンク';

$side[0][0] = 'サンプル<a href="http://hogehoge.co.jp/">PR_Link6‐サンプル</a>リンク';
$side[0][1] = 'サンプルサンプルサンプルサンプル<a href="http://hogehoge.co.jp/">PR_Link7‐サンプルサンプル</a>サンプルサンプルサンプルサンプルサンプルサンプルリンク';
$side[0][2] = 'サンプルサンプル<a href="http://hogehoge.co.jp/">PR_Link8‐サンプルサンプル</a>サンプルリンク';
$side[0][3] = 'サンプル<a href="http://hogehoge.co.jp/">PR_Link9‐サンプルサンプルサンプルサンプル</a>サンプルサンプルサンプルリンク';
$side[0][4] = '<a href="http://hogehoge.co.jp/">PR_Link10‐サンプルサンプル</a>サンプルリンク';

$side[1][0] = 'サンプル<a href="http://hogehoge.co.jp/">PR_Link11‐サンプル</a>リンク';
$side[1][1] = 'サンプルサンプルサンプルサンプル<a href="http://hogehoge.co.jp/">PR_Link12‐サンプルサンプル</a>サンプルサンプルサンプルサンプルサンプルサンプルリンク';
$side[1][2] = 'サンプルサンプル<a href="http://hogehoge.co.jp/">PR_Link13‐サンプルサンプル</a>サンプルリンク';
$side[1][3] = 'サンプル<a href="http://hogehoge.co.jp/">PR_Link14‐サンプルサンプルサンプルサンプル</a>サンプルサンプルサンプルリンク';
$side[1][4] = '<a href="http://hogehoge.co.jp/">PR_Link15‐サンプルサンプル</a>サンプルリンク';

$contents[0] = 'サンプル<a href="http://hogehoge.co.jp/">PR_Link16‐サンプル</a>リンク';
$contents[1] = 'サンプルサンプルサンプルサンプル<a href="http://hogehoge.co.jp/">PR_Link17‐サンプルサンプル</a>サンプルサンプルサンプルサンプルサンプルサンプルリンク';
$contents[2] = 'サンプルサンプル<a href="http://hogehoge.co.jp/">PR_Link18‐サンプルサンプル</a>サンプルリンク';
$contents[3] = 'サンプル<a href="http://hogehoge.co.jp/">PR_Link19‐サンプルサンプルサンプルサンプル</a>サンプルサンプルサンプルリンク';
$contents[4] = '<a href="http://hogehoge.co.jp/">PR_Link20‐サンプルサンプル</a>サンプルリンク';

$kousin[0][0] = 'サンプル<a href="http://hogehoge.co.jp/">PR_Link21‐サンプル</a>リンク';
$kousin[0][1] = 'サンプルサンプルサンプルサンプル<a href="http://hogehoge.co.jp/">PR_Link22‐サンプルサンプル</a>サンプルサンプルサンプルサンプルサンプルサンプルリンク';
$kousin[0][2] = 'サンプルサンプル<a href="http://hogehoge.co.jp/">PR_Link23‐サンプルサンプル</a>サンプルリンク';
$kousin[0][3] = 'サンプル<a href="http://hogehoge.co.jp/">PR_Link24‐サンプルサンプルサンプルサンプル</a>サンプルサンプルサンプルリンク';
$kousin[0][4] = '<a href="http://hogehoge.co.jp/">PR_Link25‐サンプルサンプル</a>サンプルリンク';

$kousin[1][0] = 'サンプル<a href="http://hogehoge.co.jp/">PR_Link26‐サンプル</a>リンク';
$kousin[1][1] = 'サンプルサンプルサンプルサンプル<a href="http://hogehoge.co.jp/">PR_Link27‐サンプルサンプル</a>サンプルサンプルサンプルサンプルサンプルサンプルリンク';
$kousin[1][2] = 'サンプルサンプル<a href="http://hogehoge.co.jp/">PR_Link28‐サンプルサンプル</a>サンプルリンク';
$kousin[1][3] = 'サンプル<a href="http://hogehoge.co.jp/">PR_Link29‐サンプルサンプルサンプルサンプル</a>サンプルサンプルサンプルリンク';
$kousin[1][4] = '<a href="http://hogehoge.co.jp/">PR_Link30‐サンプルサンプル</a>サンプルリンク';
?>