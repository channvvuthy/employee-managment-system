<?php $rootpass = realpath(dirname(__FILE__)) . '/'; ?>
<?php $pn = '5'; ?>
<?php require_once $rootpass.'include/header.php'; ?>
<?php require_once $rootpass.'area_all.php' ; ?>