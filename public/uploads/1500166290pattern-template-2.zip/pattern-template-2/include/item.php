<?php

//内部ページの画像の設定
$pageimage[1][1]  ='top_content.jpg';
$pageimage[2][1]  ='i-catch1.jpg';
$pageimage[3][1]  ='i-catch2.jpg';
$pageimage[4][1]  ='i-catch3.jpg';
$pageimage[5][1]  ='i-catch4.jpg';
$pageimage[6][1]  ='i-catch5.jpg';
$pageimage[7][1]  ='';
$pageimage[8][1]  ='';
$pageimage[9][1]  ='';
$pageimage[10][1]  ='';
$pageimage[11][1]  ='';
$pageimage[12][1]  ='';
$pageimage[13][1]  ='';
$pageimage[14][1]  ='';
$pageimage[15][1]  ='';
$pageimage[16][1]  ='';
$pageimage[17][1]  ='';
$pageimage[18][1]  ='';
$pageimage[19][1]  ='';
$pageimage[20][1]  ='';
$pageimage[21][1]  ='';
$pageimage[22][1]  ='';
$pageimage[23][1]  ='';
$pageimage[24][1]  ='';
$pageimage[25][1]  ='';
$pageimage[26][1]  ='';
$pageimage[27][1]  ='';
$pageimage[28][1]  ='';
$pageimage[29][1]  ='';
$pageimage[30][1]  ='';
$pageimage[31][1]  ='';

//内部ページのaltの設定
$pagealt[1][1]  ='';
$pagealt[2][1]  ='';
$pagealt[3][1]  ='';
$pagealt[4][1]  ='';
$pagealt[5][1]  ='';
$pagealt[6][1]  ='';
$pagealt[7][1]  ='';
$pagealt[8][1]  ='';
$pagealt[9][1]  ='';
$pagealt[10][1]  ='';
$pagealt[11][1]  ='';
$pagealt[12][1]  ='';
$pagealt[13][1]  ='';
$pagealt[14][1]  ='';
$pagealt[15][1]  ='';
$pagealt[16][1]  ='';
$pagealt[17][1]  ='';
$pagealt[18][1]  ='';
$pagealt[19][1]  ='';
$pagealt[20][1]  ='';
$pagealt[21][1]  ='';
$pagealt[22][1]  ='';
$pagealt[23][1]  ='';
$pagealt[24][1]  ='';
$pagealt[25][1]  ='';
$pagealt[26][1]  ='';
$pagealt[27][1]  ='';
$pagealt[28][1]  ='';
$pagealt[29][1]  ='';
$pagealt[30][1]  ='';
$pagealt[31][1]  ='';

?>