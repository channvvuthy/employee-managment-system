<?php $rootpass = realpath(dirname(__FILE__)) . '/'; ?>
<?php $pn = '15'; ?>
<?php require_once $rootpass.'include/header.php'; ?>
<?php require_once $rootpass.'area_all.php' ; ?>